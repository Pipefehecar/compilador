from django.conf.urls import url, include
from views import RegistrarUsuario, login

urlpatterns = [
    # url(r'^$', 'apps.login.views.index'),
    # url(r'^$', views.index, name='index'),
    url(r'^registrar/$', RegistrarUsuario.as_view(), name='registrar_usuario'),
    # url(r'^index2/$', index2.as_view(), name='index2'),
    url(r'^login/$', login.as_view(), name='login'),
] 


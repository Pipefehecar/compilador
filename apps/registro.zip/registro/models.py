# -*- coding: utf-8 -*-

from __future__ import unicode_literals

from django.db import models

# Create your models here.
class Usuario(models.Model):
	nombres = models.CharField(max_length=50)
	apellidos = models.CharField(max_length=50)
	email = models.EmailField()
	#edad = models.IntegerField()
	pais = models.CharField(max_length=50)
	ciudad = models.CharField(max_length=50)
	lenguaje_de_programacion = models.CharField(max_length=50)

	def __unicode__(self):
		return self.nombres
# -*- coding: utf-8 -*-
from __future__ import unicode_literals

#from django.shortcuts import render_to_response
from django.views.generic import CreateView
from django.views.generic import TemplateView
from django.core.urlresolvers import reverse_lazy

from models import Usuario
# Create your views here.
# def index(request):
# 	return render_to_response('login/index.html')
class RegistrarUsuario(CreateView):
	template_name = 'registro/registrarUsuario.html'
	model = Usuario
	success_url = reverse_lazy('login')
	fields = '__all__'

class login(TemplateView):
	template_name = 'registro/login.html'